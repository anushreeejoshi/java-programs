package com.set.sort;

import java.util.HashSet;
import java.util.Iterator;



public class HashSetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> hob=new HashSet<Integer>();
		hob.add(21);
		hob.add(11); //order is not maintain
		hob.add(12);
		hob.add(12);//no duplicate value will stored
		
		System.out.println(hob);
		
		HashSet<String> hob1=new HashSet<String>();
		hob1.add("Shivi");
		hob1.add("Anu");
		hob1.add("Vami");
		hob1.add(null);//single null is allowed
		hob1.add(null);
		
		System.out.println(hob1);
		
		System.out.println("With Iterator");
		Iterator<String> it=hob1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
