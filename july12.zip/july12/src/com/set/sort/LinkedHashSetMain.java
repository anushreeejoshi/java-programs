package com.set.sort;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedHashSet<Integer> lhs=new LinkedHashSet<Integer>();
		lhs.add(11); //maintain the insertion order
		lhs.add(9);
		lhs.add(22);
		lhs.add(22); //duplicates not allowed
		lhs.add(null);//one null is allowed
		lhs.add(null);
		System.out.println(lhs);
		
		LinkedHashSet<String> lhs1=new LinkedHashSet<String>();
		lhs1.add("Shivi"); //maintain the insertion order
		lhs1.add("Anu");
		lhs1.add("Sanvi");
		lhs1.add("Hari"); //duplicates not allowed
		lhs1.add(null);//one null is allowed
		lhs1.add(null);
		System.out.println(lhs1);
		
		System.out.println("With Iterator");
		Iterator<Integer> its=lhs.iterator();
		while(its.hasNext()) {
			System.out.println(its.next());
		}
	}

}
