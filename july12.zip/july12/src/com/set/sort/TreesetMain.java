package com.set.sort;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<Integer> tob=new TreeSet<Integer>();
		tob.add(21);//ascending order maintain
		tob.add(11);
		tob.add(12);
		tob.add(12);//no duplicate value will stored
		
		System.out.println(tob);
		
		TreeSet<String> tob1=new TreeSet<String>();
		tob1.add("Shivi");
		tob1.add("Anu");
		tob1.add("Vami");
		tob1.add("Vami");
		//tob1.add(null); //null is not allowed
		
		
		System.out.println(tob1);
		
		System.out.println("With Iterator");
		Iterator<String> it=tob1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
