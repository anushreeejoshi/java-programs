package com.java.product;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product p1=new Product(1210, "TV", 56232);
		Product p2=new Product(1121, "Camera", 50032);
		Product p3=new Product(1221, "Radio", 55532);
		Product p4=new Product(1201, "Phone", 51232);
		
		ArrayList<Product> first=new ArrayList<Product>();
		first.add(p1);
		first.add(p2);
		first.add(p3);
		first.add(p4);
		
		//sorting price
		SortProductPrice pr=new SortProductPrice();
		
		Collections.sort(first,pr);
		
		System.out.println("Sorting price");
		
		Iterator<Product> pit=first.iterator();
		System.out.println("PID\tPName\tPPrice");
		while(pit.hasNext()) {
			Product pt=pit.next();
			System.out.println(pt.pid+"\t"+pt.pname+"\t"+pt.pprice);
			
		}
		//sorting id
		SortProductId pr1=new SortProductId();
		
		Collections.sort(first,pr1);
		
		System.out.println("Sorting Id");
		
		Iterator<Product> pit1=first.iterator();
		System.out.println("PID\tPName\tPPrice");
		while(pit1.hasNext()) {
			Product pt1=pit1.next();
			System.out.println(pt1.pid+"\t"+pt1.pname+"\t"+pt1.pprice);
			
		}
		//sorting name
		SortProductName pn=new SortProductName();
		Collections.sort(first,pn);
		
		System.out.println("Sort Name");
		Iterator<Product> pit2=first.iterator();
		System.out.println("PID\tPName\tPPrice");
		while(pit2.hasNext()) {
			Product pt2=pit2.next();
			System.out.println(pt2.pid+"\t"+pt2.pname+"\t"+pt2.pprice);
			
		}
	}

}
