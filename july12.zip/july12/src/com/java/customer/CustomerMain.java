package com.java.customer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class CustomerSortId implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		// TODO Auto-generated method stub
		if(o1.cid==o2.cid) {
		return 0;
	}else if(o1.cid>o2.cid) {
		return 1;
	}else {
		return -1;
	}
	
}
}
class CustomerSortName implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		// TODO Auto-generated method stub
		return o1.cname.compareTo(o2.cname);
	}
	
}
class CustomerSortAmt implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		// TODO Auto-generated method stub
		if(o1.amt==o2.amt) {
			return 0;
		}
		else if(o1.amt>o2.amt) {
			return 1;
			
		}else {
			return -1;
		}
	}
	
}
public class CustomerMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Customer cus1 =new Customer(2, "Sanvi", 21332f);
		Customer cus2=new Customer(1, "Raavi", 12232f);
		Customer cus3=new Customer(3, "Anvi", 19233f);
		
		ArrayList<Customer> arcus=new ArrayList<Customer>();
		arcus.add(cus1);
		arcus.add(cus2);
		arcus.add(cus3);
		
		//sorting id
		CustomerSortId id=new CustomerSortId();
		Collections.sort(arcus,id);
		System.out.println("Sorting ID");
		Iterator<Customer> dit=arcus.iterator();
		System.out.println("CID\tCNAME\tCAMT");
		while(dit.hasNext()) {
			Customer c1=dit.next();
			System.out.println(c1.cid+"\t"+c1.cname+"\t"+c1.amt);
		}
		//sorting name
		CustomerSortName nam =new CustomerSortName();
		Collections.sort(arcus,nam);
		
		System.out.println("Sorting Name:");
		Iterator<Customer> nit=arcus.iterator();
		System.out.println("CID\tCNAME\tCAMT");
		while(nit.hasNext()) {
			Customer c2=nit.next();
			System.out.println(c2.cid+"\t"+c2.cname+"\t"+c2.amt);
		}
		//sorting amount
		CustomerSortAmt amnt=new CustomerSortAmt();
		Collections.sort(arcus,amnt);
		
		System.out.println("Sorting Amount");
		Iterator<Customer> amit=arcus.iterator();
		System.out.println("CID\tCNAME\tCAMOUNT");
		while(amit.hasNext()) {
			Customer c3=amit.next();
			System.out.println(c3.cid+"\t"+c3.cname+"\t"+c3.amt);
		}
	}

}
