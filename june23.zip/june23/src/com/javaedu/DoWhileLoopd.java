package com.javaedu;

public class DoWhileLoopd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		do {
			System.out.println("do while");
		}while(i==0);
	}

}
