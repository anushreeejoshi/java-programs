package com.javaedu;

import java.util.Scanner;

public class BreakAndContinue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			System.out.println(i);
			i=i+1;
			System.out.println("to stop enter n to continue enter any other ");
			char ch=sc.next().charAt(0);
			if(ch=='n') {
				break;
			}
			else {
				continue;
			}
		}
	}

}
