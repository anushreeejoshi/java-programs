package java8features;
//functional interface lambda expression with args
interface CallInterface{
	void myCallMethod(String s);
	//for returning string
	//String myCallMethod(String s);
	
}
public class MainInterface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CallInterface cob=( s)->{
			System.out.println("My call method "+s);
		};
		cob.myCallMethod("hello");
		
		//if we are implementing single line then no need to give curly braces{}
		CallInterface cob1=( s)->System.out.println("My call method "+s);
		cob1.myCallMethod("hello");
		
		//if we are giving return statement
//		CallInterface cob2=(s)->{
//			return "hello "+s;
//		};
//		String sob=cob2.myCallMethod("Anushree");
//		System.out.println(sob);
	}

}
