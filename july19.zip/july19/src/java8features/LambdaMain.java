package java8features;
interface LambdaInterface{
	void myFunct();
}
class HelloClass implements LambdaInterface{

	@Override
	public void myFunct() {
		// TODO Auto-generated method stub
		System.out.println("hello interface");
	}
	
}
public class LambdaMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HelloClass ob=new HelloClass();
		ob.myFunct();
		LambdaInterface ob1 =new LambdaInterface() {
			
			@Override
			public void myFunct() {
				// TODO Auto-generated method stub
				System.out.println("hello interface");
			}
		};
		ob.myFunct();
		
		//Lambda Expression:functional programming
		
		LambdaInterface ob2=()->{
			System.out.println("interface function");
		};
		ob1.myFunct();
		
		Runnable rob=()->{
			System.out.println("runmethod is called");
		};
		Thread tob=new Thread();
		tob.start();
	}

}
