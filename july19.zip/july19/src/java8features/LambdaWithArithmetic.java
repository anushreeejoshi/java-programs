package java8features;
//lambda functional expression
interface LambdaAdd{
	int add(int a,int b);
}
interface LambdaSub{
	int sub(int a,int b);
}
interface LambdaMul{
	int mul(int a,int b);
}
interface LambdaDiv{
	int div(int a,int b);
}
public class LambdaWithArithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LambdaAdd la=(a,b)->{
			return (a+b);
		};
		int ans=la.add(23, 12); 
		System.out.println("Addition is "+ans);
		
		LambdaSub ls=(a,b)->a-b;
		System.out.println("Subtraction is "+ls.sub(30,10));
		
		LambdaMul lm=(a,b)->a*b;
		System.out.println("Multiplication is "+lm.mul(10, 5));
		
		LambdaDiv ld=(a,b)->a/b;
		System.out.println("Division is "+ld.div(10, 2));
	}

}
