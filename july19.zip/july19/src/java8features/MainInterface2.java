package java8features;
interface MyInterfaceone{
	void display(int a, String s);
}
interface Interface1{
	int view(int a,int b);
}
public class MainInterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyInterfaceone mob=(a,s)->{
			System.out.println("id "+a+" name "+s);
		};
		mob.display(1, "anu");
		
		Interface1 ob=(a,b)->{
			return (a+b);
		};
//		ob.view(23, 12);
		System.out.println(ob.view(23, 12));
	}

}
