package java8features;
interface MyInterface1{
	void method1();
	default void message() {
		System.out.println("MyInterface1");
	}
}
interface MyInterface2{
	void method2();
	default void message() {
		System.out.println("MyInterface2");
	}
}
class MessageClass implements MyInterface1,MyInterface2{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("method1");
	}
	@Override
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("method2");
	}
	@Override
	public void message() {
		// TODO Auto-generated method stub
		MyInterface1.super.message();
	}

	
	
}
public class MainMultipleInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MessageClass ob=new MessageClass();
		ob.message();
		ob.method1();
		ob.method2();
	}

}
