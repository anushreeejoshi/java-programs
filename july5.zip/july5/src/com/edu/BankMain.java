package com.edu;

abstract class Bank{
	abstract float rateofInterest(); //abstract method does not have body
	 void display() {
		System.out.println("Display method");
	}
	 
	  Bank(){
		System.out.println("hello");
	}
}
class SBI extends Bank{

	@Override
	 float rateofInterest() {
		// TODO Auto-generated method stub
		return 7.5f;
	}
	
}
class HDFC extends Bank{

	@Override
	 float rateofInterest() {
		// TODO Auto-generated method stub
		return 6.5f;
	}
	
}
public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		SBI sob=new SBI();
		System.out.println("Rate of interest SBI= "+sob.rateofInterest());
		sob.display();
		HDFC hob=new HDFC();
		System.out.println("Rate of interest HDFC= "+hob.rateofInterest());
		hob.display();
		
		
		
	}

}
