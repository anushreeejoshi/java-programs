//public - package to package it is visible 
//default- with in package all the class can access with object ref
//         other package default cannot be accessed (default becomes private)
//protected- with in package it behaves like default another package only child class can access
//private- visibility is within class
package p2;

import p1.AccessModifierMain;

public class ClassMain {

	protected int sum() {
		return 2+3;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccessModifierMain obj =new AccessModifierMain();
		obj.display(); //accessing method from p1 package
	}

}
