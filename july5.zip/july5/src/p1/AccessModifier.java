//public - package to package it is visible 
//default- with in package all the class can access with object ref
//         other package default cannot be accessed (default becomes private)
//protected- with in package it behaves like default another package only child class can access
//private- visibility is within class
package p1;

public class AccessModifier {

	
	protected void display2(){
		System.out.println("hello from protected method ");
	}
	 void show() {
			System.out.println("hello from default method");
		}

}
