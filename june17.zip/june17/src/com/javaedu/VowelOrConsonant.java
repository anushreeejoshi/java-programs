package com.javaedu;

import java.util.Scanner;

public class VowelOrConsonant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char ch;
		String letter;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter anu char:");
		ch=sc.next().charAt(0);
		
		
//			boolean True=true;
//			boolean False = false;
//			String PrintS="Vowel";
		
		
		letter=(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')? "vowel" : "consonants";
		System.out.println(letter);
			
		
	}

	
}