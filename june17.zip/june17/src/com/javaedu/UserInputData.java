package com.javaedu;

import java.util.Scanner;

public class UserInputData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		String name;
		int age;
		float fees;
		double amount;
		char gen;
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		name=sc.nextLine();
		System.out.println("enter age");
		age=sc.nextInt();
		System.out.println("enter fees");
		fees=sc.nextFloat();
		System.out.println("enter amount");
		amount=sc.nextDouble();
		System.out.println("enter gender");
		gen=sc.next().charAt(0);
		
		
		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
		System.out.println("Fees:"+fees);
		System.out.println("Amount:"+amount);
		System.out.println("Gender:"+gen);
		
	}

}
