package com.javaedu;

import java.util.Scanner;

public class LargestOrSmallest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int first,second,large;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr 1st Number");
		first=sc.nextInt();
		second=sc.nextInt();
		
		large=(first>second)?first:second;
		System.out.println("Largest of "+first+" and "+second+" is :"+large);
		
		
	}

}
