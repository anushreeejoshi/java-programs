package com.javaedu;

import java.util.Scanner;

class Largest{
	int arr[];
	int size;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array:");
		size=sc.nextInt();
		arr=new int[size];
	}
	void displayElements() {
		System.out.println("Enter array elements:");
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
	}
	void findLargest(){
		int max=arr[0];
		for(int i=0;i<size;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println("Largest of array element is: "+max);
	}
}
public class LargestOfArrayElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Largest largObj=new Largest();
		largObj.inputData();
		largObj.displayElements();
		largObj.findLargest();
		
		
		
		
	}

}
