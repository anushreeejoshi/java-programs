package com.javaedu;

import java.util.Scanner;

class CheckPalindrome{
	int num,d,temp,sum;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		num=sc.nextInt();
		}
		
		void checkData() {
			temp=num;
			while(num!=0) {
				d=num%10;
				sum=(sum*10)+d;
				num=num/10;
				
			}
				if(temp==sum) {
					System.out.println("Palindrome");
				}else {
					System.out.println("Not Palindrome");
				}
			}
			
			
		
		
	}

public class PalindromeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CheckPalindrome cp1=new CheckPalindrome();
		cp1.inputData();
		cp1.checkData();
		
	}

}
