package com.javaedu;

public class PrintName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		while(i<=10) {
			System.out.println("Anushree"+i);
			i++;
		}
	}

}
