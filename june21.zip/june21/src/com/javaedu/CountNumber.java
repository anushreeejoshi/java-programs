package com.javaedu;

import java.util.Scanner;

class Count{
	int count;
	int num,d;
	
	void inputData() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Number:");
	num=sc.nextInt();
	}
	
	void displayData() {
		while(num!=0) {
			d=num%10;
			num=num/10;
			count=count+1;
		}
		System.out.println("Number of Digit is:"+count);
		
	
	
}
}

public class CountNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Count c1=new Count();
		c1.inputData();
		c1.displayData();
		
	}

}
