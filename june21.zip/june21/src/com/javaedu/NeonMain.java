package com.javaedu;

import java.util.Scanner;

class NeonNumber{
	int sum,n,square,digit;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any Number:");
		n=sc.nextInt();
		
	}
	
	void calSquare(){
		 square=n*n;
		
	}
	void checkNeon() {
		while(square!=0) {
			digit=square%10;
		    sum=sum+digit;
		    square=square/10;
		}
		    
	     if(n==sum) {
			System.out.println(n+" is a Neon Number");
		}
		else {
			System.out.println(n+" is not a Neon Number");
		}
	}
}

	

public class NeonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NeonNumber nm=new NeonNumber();
		nm.inputData();
		nm.calSquare();
		
	}

}
