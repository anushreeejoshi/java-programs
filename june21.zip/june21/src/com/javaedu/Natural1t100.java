package com.javaedu;

public class Natural1t100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		while(i<=100) {
			System.out.println(i);
			i++;
		}
	}

}
