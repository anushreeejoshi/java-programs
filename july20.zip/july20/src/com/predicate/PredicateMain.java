package com.predicate;

import java.util.function.Predicate;

public class PredicateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("predicate ex");
		Predicate<Integer> pob=(i)->(i>10);
		
		/*if(i>10){
		 * return true;}
		 * else{
		 * return false;}
		 */
		boolean val=pob.test(12);
		System.out.println("result "+val);
		
		String s1="Anu";
		Predicate<String> pobs=(s)->(s==s1);
		boolean val1=pobs.test("anu");
		System.out.println(val1);
		
		
	}

}
