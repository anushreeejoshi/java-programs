package com.predicate;

import java.util.function.Function;

public class FunctionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="How are you?";
		
		Function<String,Integer>fob=(s1)->s.length();
		System.out.println("Calls function use apply "+fob.apply(s));
		
	}

}
