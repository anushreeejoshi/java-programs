package com.predicate;

import java.util.function.Predicate;

public class PredicateMain2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[]arr= {8,7,11,13,14,15,17};
		
		Predicate<Integer> gt=(i)->(i>10);
		System.out.println("num is greater than 10:");
		myMethod(gt,arr);
		
	}

	private static void myMethod(Predicate<Integer> p, Integer[] arr) {
		// TODO Auto-generated method stub
		for(Integer i:arr) {
			if(p.test(i))
				System.out.println(i+" ");
		}
	}

}
