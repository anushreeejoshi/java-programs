package com.predicate;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamApiMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> lst=new ArrayList<Integer>();
		for(int i=1;i<=100;i++) {
			lst.add(i);
		}
		System.out.println(lst);
		Stream<Integer>s=lst.stream();
		
		List<Integer>ls=s.filter(i->i>75).collect(Collectors.toList());
		System.out.println(ls);
		
		//or
		List<Integer>lst1=new ArrayList<Integer>();
		Iterator<Integer>it=lst.iterator();
		while(it.hasNext()) {
			int i=it.next();
			if(i>75) {
				lst1.add(i);
			}
		}
		System.out.println("New List="+lst1);
	}

}
