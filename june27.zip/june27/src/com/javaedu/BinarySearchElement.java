package com.javaedu;
import java.util.Scanner;

class BinarySearch{
	int arr[],size,temp=0;
	
	void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size for array:");
		size=sc.nextInt();
		arr=new int[size];
		
		System.out.println("Enter "+size+" element for array:");
		for(int i=0;i<size;i++) {
			arr[i]=sc.nextInt();
		}
	}
	
	void sortElements() {
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		System.out.println("Sorted Array: ");
		for(int i=0;i<size;i++) {
			System.out.println(arr[i]);
		}
	}
	
	void binarySearch() {
		int search;
		int left=0;
		int right=size-1;
		int mid;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter element to search:");
		search=sc.nextInt();
		
		while(left<=right) {
			mid=(left+right)/2;
		if(arr[mid]==search) {
			System.out.println("Element found at: "+mid);
			break;
		}
		else if(arr[mid]<search) {
			left = mid+1;
			System.out.println("Element found at: "+left);
		}
		else {
			right=mid-1;
			System.out.println("Element found at: "+right);
		}
//		mid=(left+right)/2;
	}
		
//		if(left>right) {
//			System.out.println("Element not found");
//		}
	}	
}



public class BinarySearchElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		BinarySearch bs=new BinarySearch();
		bs.inputData();
		bs.sortElements();
		bs.binarySearch();
		
		
		
		
	}

}
