package com.javaedu;

import java.util.Scanner;

class LinearSearch{
int arr[],size;	

void inputData() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter size of array:");
	size=sc.nextInt();
	arr=new int[size];
	System.out.println("Enter "+size+" element for array:");
	for(int i=0;i<size;i++) {
		arr[i]=sc.nextInt();
	}
	
}
void search() {
	int search;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter elment to search:");
	search=sc.nextInt();
	
	for(int i=0;i<size;i++) {
	if(arr[i]==search) {
		System.out.println("Element found at "+i);
		break;
	}
	else {
		System.out.println("Element not found");
	}
}
}
}
public class LinearSearchElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinearSearch lsobj=new LinearSearch();
		lsobj.inputData();
		lsobj.search();
	}

}
