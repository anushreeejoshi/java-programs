package com.javaedu;

import java.util.Scanner;

public class LargestOfThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int first,second,third,large;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter three number:");
		first =sc.nextInt();
		second =sc.nextInt();
		third =sc.nextInt();
		
		large=(first>second && first>third)? first : (second>first && second>third) ? second :  third;
		System.out.println("Largest Number is :"+large);
	}

}
