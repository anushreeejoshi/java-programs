package com.javaedu;

import java.util.Scanner;

public class LargestOfFour {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

       int first,second,third,four,large;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter three number:");
		first =sc.nextInt();
		second =sc.nextInt();
		third =sc.nextInt();
		four=sc.nextInt();
		
		large=(first>=second && first>=third && first>=four)? first : (second>=first && second>=third && second>=four) ? second : (third>=first && third>=second && third>=four)? third:four;
		System.out.println("Largest Number is :"+large);
	}

}
