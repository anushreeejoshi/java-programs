package com.javaedu;

import java.util.Scanner;

public class Marks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		float marks;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Marks:");
		marks=sc.nextFloat();
		
		if(marks>=80&&marks<=100) {
			System.out.println("Grade A");
		}
		else if(marks>=60 && marks<=79){
			System.out.println("Grade B");
		}
		else if(marks>=35 && marks<=59) {
			System.out.println("Grade C");
			
		}
		else if(marks>0 && marks<=34){
			System.out.println("Failed");
		}
		else {
			System.out.println("Invalid Input");
			}
		}
	}


