package com.javaedu;

import java.util.Scanner;

class ShowRoom{
	String name;
	long mobno;
	double cost;
	double discount;
	double amount;
	
	ShowRoom() {
		name=null;
		mobno=0;
		cost=0.0;
		discount=0.0;
		amount=0.0;
	}
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name:");
		name=sc.nextLine();
		System.out.println("Enter your mobile number:");
		mobno=sc.nextLong();
		System.out.println("Enter cost:");
		cost=sc.nextDouble();
		
	}
	void calculate() {
		if(cost<=10000) {
			discount=(cost*5)/(100);
		}
		else if(cost>10000 && cost<=20000) {
			discount=(cost*10)/100;
		}
		else if(cost>20000 && cost<=35000) {
			discount=(cost*15)/100;
		}
		else if(cost>35000) {
			discount=(cost*20)/100;
		}
	}
	void display() {
		System.out.println("Name:"+name);
		System.out.println("Your Mobile No. :"+mobno);
		System.out.println("Amount to be paid: "+(cost-discount));
		
	}
}
public class ShowRoomMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ShowRoom obj=new ShowRoom();
		obj.input();
		obj.calculate();
		obj.display();
	}

}
