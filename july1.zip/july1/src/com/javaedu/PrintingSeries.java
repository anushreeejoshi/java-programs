package com.javaedu;
class OverloadSeries{
	
	void series(int x, int n) {
		double s=0;
		for(int i=1;i<=n;i++) {
			s=s+Math.pow(x, i);
		}
		System.out.println("sum of the series(x1+x2+x3+...xn): "+s);
	}
	void series(int p) {
		for(int i=1;i<=p;i++) {
			System.out.print((i*i*i)-1+" , ");
		}
		System.out.println();
	}
	void series() {
		double s=0;
		for(int i=2;i<=10;i++) {
			s=s+((double)1/i);
		}
		System.out.println("Sum of series(1/2+1/3+1/4....+1/10): "+s);
	}
}

public class PrintingSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OverloadSeries obj1=new OverloadSeries();
		obj1.series();
		obj1.series(6);
		obj1.series(2, 10);
	}

}
