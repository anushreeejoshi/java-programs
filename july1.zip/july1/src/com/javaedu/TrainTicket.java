package com.javaedu;

import java.util.Scanner;

class RailwayTicket{
	String name;
	String coach;
	long mobno;
	int amt;
	int totalamt;
	
	
	void accept() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name: ");
		name=sc.nextLine();
		System.out.println("Enter Coach: ");
		coach=sc.nextLine();
		System.out.println("Enter Mobile No.");
		mobno=sc.nextLong();
		System.out.println("Enter Amount:");
		amt=sc.nextInt();

	}
	
	void update() {
		
		if( coach.equalsIgnoreCase("First_AC")) {

			totalamt=amt+700;
			
		}
		else if(coach.equalsIgnoreCase("Second_AC")) {

			totalamt=amt+500;
		}
		else if(coach.equalsIgnoreCase("Third_AC")) {

			totalamt=amt+250;
		}
		else if(coach.equalsIgnoreCase("Sleeper")) {

			totalamt=amt;
			
		}
		else {
			System.out.println("Invalid coach");
		}
		
	}
	void display() {
		System.out.println("Your Name: "+name);
		System.out.println("Your Coach: "+coach);
		System.out.println("Your Mobile No.: "+mobno);
//		System.out.println("Your amount:"+amt);
		System.out.println("Your Total Amount:"+totalamt);
	}
	
	}

public class TrainTicket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RailwayTicket rt=new RailwayTicket();
		rt.accept();
		rt.update();
		rt.display();
	}

}
