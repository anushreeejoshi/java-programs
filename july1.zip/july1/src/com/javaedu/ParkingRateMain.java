package com.javaedu;

import java.util.Scanner;

class ParkingRate{
	int vno;
	int hours;
	
	double bill;
	
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Vehicle num: ");
		vno=sc.nextInt();
		System.out.println("Enter how many hours: ");
		hours=sc.nextInt();
		
		}
	void calculate() {
		
		
		if(hours<=1) {
			bill=3;
		}
		else if(hours>1){
			bill=(hours-1)*1.50+3;
		}
	}
	void display() {
		System.out.println("Your Vehicle Number: "+vno);
		System.out.println("Your Parking Hours: "+hours);
		System.out.println("Your Bill Amount: "+bill);
	}
}
public class ParkingRateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ParkingRate pr=new ParkingRate();
		pr.input();
		pr.calculate();
		pr.display();
	}

}
