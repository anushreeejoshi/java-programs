package com.javaedu;

class AreaFigures{
	
	void area(int l,int b) {
		int ar=l*b;
		System.out.println("Area of rectangle: "+ar);
	}
	void area(int side) {
		int ar=side*side;
		System.out.println("Area of a square: "+ar);
	}
	void area(float r) {
		float ar;
		ar=3.14159f*r*r;
		System.out.println("Area of a circle: "+ar);
	}
	void area(float b,float h) {
		float ar;
		ar=(b*h)*0.5f;
		System.out.println("Area of a tringle: "+ar);
	}
	
}
public class OverloadFuncArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AreaFigures areaobj=new AreaFigures();
		areaobj.area(12, 22);
		areaobj.area(11);
		areaobj.area(10.3f);
		areaobj.area(5.5f, 6.3f);
		
	}

}
