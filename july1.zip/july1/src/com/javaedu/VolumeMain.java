//find volume of sphere, cylinder, Cuboid .
package com.javaedu;
class VolumeOverload{
	
	void volume(double r) { //radius
		double v=(4/3)*(22/7)*(r*r*r);
		System.out.println("Volume of sphere: "+v);
	}
	void volume(double h,double r) { //height, radius
		double v=(22/7)*(r*r)*h;
		System.out.println("Volume of cylinder: "+v);
	}
	void volume(double l,double b,double h) { //length, breadth, height
		double v=l*b*h;
		System.out.println("Volume is cuboid: "+v);
	}
}
public class VolumeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		VolumeOverload obj1=new VolumeOverload();
		obj1.volume(4.5);
		obj1.volume(2.4, 1.3);
		obj1.volume(4.2, 2.1, 3.3);
		
	}

}
