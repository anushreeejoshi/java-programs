package com.javaedu;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class VowelsAndConsonants {

	static int i=1;
	int j;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int count=0;
//		ArrayList<Character> aobj= new ArrayList<Character>();
//		
//		Scanner sc=new Scanner(System.in);
//		String str=sc.nextLine();
//		
//		for(char ch:str.toCharArray()) {
//			
//			aobj.add(ch);
//			
//		}
//		Iterator<Character>it=aboj.iterator();
//		TreeSet<Character>ts=new TreeSet<Character>();
//		while(it.hasNext()) {
//			
//		}
		
		System.out.println("Hello"+6+8);//hello68
		System.out.println(6+8+"hello");//14hello
		
		byte b=127;
		System.out.println(i);
		VowelsAndConsonants vc=new VowelsAndConsonants();
          System.out.println(vc.j);
}

}

