package com.javaedu;


import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

public class MainVector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vector<String> lob=new Vector<String>();
		lob.add("Anu");
		lob.add("Shivani");
		lob.add("Abhi");
		lob.add("Sakshi");
		System.out.println(lob);
		lob.remove(1);
		Vector<String> lob1=new Vector<String>();
		lob1.add("One");
		lob1.add("Two");
		lob.addAll(lob1);
		lob1.add("Sona");
		System.out.println("Anu is present "+lob.contains("Anu"));
		System.out.println(lob.containsAll(lob1));
		System.out.println(lob.indexOf("Abhi"));
		
		//Iterator elements using Iterator
		Iterator<String>it=lob.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		//for each enhanced
		for(String s:lob) {
			System.out.println(s);
		}
		//sorting 
		Collections.sort(lob);
		System.out.println("Sorted Vector:");
		System.out.println(lob);
		
		Collections.shuffle(lob);
		System.out.println("After shuffle "+lob);
		
		Collections.swap(lob, 1, 3);
		System.out.println("Swap "+lob);
	}

	}


