package com.user.stud;


import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;


class StudentAgeSort implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		if(o1.age>o2.age) {
			return 1;
		}else if (o1.age==o2.age) {
			return 0;
		}else {
			return -1;
		}
		
	}
	
}
class StudentIdSort implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		if(o1.sid>o2.sid) {
			return 1;
		}else if (o1.sid==o2.sid) {
			return 0;
		}else {
			return -1;
		}
	}
	
}
class StudentFeesSort implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		if(o1.sfees>o2.sfees) {
			return 1;
		}else if (o1.sfees==o2.sfees) {
			return 0;
		}else {
			return -1;
		}
		
	}
	
}
class StudentNameSort implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		return o1.sname.compareTo(o2.sname);
	}
	
}
public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1=new Student(2, "Anushree", 21, 2134.3f);
		Student s2=new Student(1, "Dhanshree", 24, 1234.3f);
		Student s3=new Student(3, "JayShree", 25, 2234.3f);
		Student s4=new Student(4, "Saishree", 23, 3234.3f);
		
		LinkedList<Student> sobj=new LinkedList<Student>();
		sobj.add(s1);
		sobj.add(s2);
		sobj.add(s3);
		sobj.add(s4);
		System.out.println(sobj);
		
		
		Iterator<Student> sit =sobj.iterator();
		System.out.println("Sid\tsname\t\tage\tsfees");
		
		while(sit.hasNext()) {
		Student s=sit.next();
		System.out.println(s.sid+"\t"+s.sname+"\t"+s.age+"\t"+s.sfees);
		}
		//Age Sort
		StudentAgeSort sob=new StudentAgeSort();
		Collections.sort(sobj,sob);
		
		System.out.println("After Sorting Age");
		Iterator<Student> sit1=sobj.iterator();
		System.out.println("Sid\tsname\t\tage\tsfees");
		
		while(sit1.hasNext()) {
			Student stud=sit1.next();
			System.out.println(stud.sid+"\t"+stud.sname+"\t"+stud.age+"\t"+stud.sfees);
	    }
		//Id sort
		StudentIdSort sob1=new StudentIdSort();
		Collections.sort(sobj,sob1);
		
		System.out.println("After Sorting Id");
		Iterator<Student> sit2=sobj.iterator();
		System.out.println("Sid\tsname\t\tage\tsfees");
		
		while(sit2.hasNext()) {
			Student stud1=sit2.next();
			System.out.println(stud1.sid+"\t"+stud1.sname+"\t"+stud1.age+"\t"+stud1.sfees);
	    }
		//Fees Sort
		StudentFeesSort sob2=new StudentFeesSort();
		Collections.sort(sobj,sob2);
		
		System.out.println("After Sorting Fees");
		Iterator<Student> sit3=sobj.iterator();
		System.out.println("Sid\tsname\t\tage\tsfees");
		
		while(sit3.hasNext()) {
			Student stud2=sit3.next();
			System.out.println(stud2.sid+"\t"+stud2.sname+"\t"+stud2.age+"\t"+stud2.sfees);
	    }
		//sorting name
		StudentNameSort sn=new StudentNameSort();
		Collections.sort(sobj,sn);
		System.out.println("After Sorting name:");
		Iterator<Student> nit=sobj.iterator();
		System.out.println("Sid\tSName\tSFees");
		while(nit.hasNext()) {
			Student stud4=nit.next();
			System.out.println(stud4.sid+"\t"+stud4.sname+"\t"+stud4.age+"\t"+stud4.sfees);
		}

}
}
	


