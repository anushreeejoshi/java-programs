package com.user.stud;

public class Student {

	int sid;
	String sname;
	int age;
	float sfees;
	public Student(int sid, String sname, int age, float sfees) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.age = age;
		this.sfees = sfees;
	}
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", age=" + age + ", sfees=" + sfees + "]";
	}
	
	
}
