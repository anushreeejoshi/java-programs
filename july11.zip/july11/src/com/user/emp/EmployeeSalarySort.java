package com.user.emp;

import java.util.Comparator;
import java.util.Iterator;

public class EmployeeSalarySort implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if(o1.esalary>o2.esalary) {
			return 1;
     	}else if (o1.esalary==o2.esalary) {
			return 0;
		}else {
			return -1;
		}
	}
	
	
	

}
