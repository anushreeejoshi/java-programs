package com.user.emp;

import java.util.Comparator;

public class EmployeeIdSort implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		
			
			if(o1.eid>o2.eid) {
				return 1;
	     	}else if (o1.eid==o2.eid) {
				return 0;
			}else {
				return -1;
			}
		}
		
	}

	

