package com.javawrap;
class OuterClassLocal{
	void outerMethodLocal(){
		class LocalInnerClass{
			void innerMethod() {
				System.out.println("Local Inner Method");
			}
		}
		LocalInnerClass lobj=new LocalInnerClass();
		lobj.innerMethod();
	}
}
public class LocalInnerClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OuterClassLocal outobj=new OuterClassLocal();
		outobj.outerMethodLocal();
	}

}
