package com.javawrap;
abstract class Product{
	abstract public void display();
}
interface MyInterface{
	void intMethod();
	void intMethod1();
}

public class AnonymousClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Anonymous class
//		        new Product(){
				Product pob=new Product() {
					
					@Override
					public void display() {
						System.out.println("Product display");
						
					}
				};//}.display;
				pob.display();
				
				MyInterface iob=new MyInterface() {
					
					@Override
					public void intMethod() {
						System.out.println("Interface method");
						
					}

					@Override
					public void intMethod1() {
						// TODO Auto-generated method stub
						
					}
				};
				iob.intMethod();
			}

		}
	


