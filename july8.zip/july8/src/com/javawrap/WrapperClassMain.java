package com.javawrap;


public class WrapperClassMain { //wrapper class in java is used to convert a primitive data type 
                                //to an object and object to a primitive data type
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Integer  i=null;
//		int j=null;
		Integer intobj=new Integer(10);
//		int i=intobj.intValue();
		int i=intobj;//unboxing:- converting an object of wrapper class to its corresponding 
		                        // primitive data type
		System.out.println(i);
		
		int num1=20;
//		Integer intobj2=Integer.valueOf(num1);
		Integer intobj2=num1;//autoboxing
		System.out.println(intobj2);
	}

}
