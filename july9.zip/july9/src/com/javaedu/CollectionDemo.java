package com.javaedu;

import java.util.ArrayList;
import java.util.Iterator;




public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//static array
//		int a[]=new int[6];
	
	//Dynamic array
		ArrayList aobj=new ArrayList();
		aobj.add(10);
		aobj.add("Anu");
		aobj.add('A');
		System.out.println("all data type:"+aobj);
		
//		//Dynamic Integer array
		ArrayList<Integer> iobj=new ArrayList<Integer>();
		iobj.add(10);
		iobj.add(11);
		iobj.add(1);
		System.out.println("integer:"+iobj);
		
//		//for each
		System.out.println("For Each Loop:");
		for(int i:iobj) {
			System.out.println(i);
		}
		
		ArrayList<Float> fob=new ArrayList<Float>();
		fob.add(778.8f);
		fob.add(21.3f);
		System.out.println("float value:"+fob);
		for(float i:fob) {
			System.out.println(i);
		}
		
		ArrayList<Double> dob=new ArrayList<Double>();
		dob.add(12.4);
		dob.add(31.32);
		System.out.println("double value:"+dob);
		for(double i:dob) {
			System.out.println(i);
		}
		
		ArrayList<String> sob=new ArrayList<String>();
		sob.add("Anu");
		sob.add("Joshi");
		sob.add("Shivani");
		sob.add("Gole");
		System.out.println("String "+sob);
		sob.remove(2);
		System.out.println("After removing:"+sob);
		for(String i:sob) {
			System.out.println(i);
		}
		
//		//using iterator fetch data// use to looping through the array list
		Iterator<String> itobj=sob.iterator();
		while(itobj.hasNext()) {
			System.out.println(itobj.next());
		}
		Iterator<Integer> intobj=iobj.iterator();
		while(intobj.hasNext()) {
			System.out.println(intobj.next());
		}
		Iterator<Double> itdobj=dob.iterator();
		while(itdobj.hasNext()) {
			System.out.println(itdobj.next());
		}
		
	

}}
