package com.user.map;

import java.util.HashMap;
import java.util.Map;


public class HashMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Integer, String> tob=new HashMap<Integer, String>();
		tob.put(1221, "Kiran");
		tob.put(3212, "Virat");
		tob.put(1100, "Anu");
		tob.put(1101, "Anu");
		tob.put(1221, "Virat");
		System.out.println(tob);
		
		//traversing
		for(Map.Entry<Integer, String> eob:tob.entrySet()){
			System.out.println(eob.getKey()+"\t"+eob.getValue());
		    }
	}
	}


