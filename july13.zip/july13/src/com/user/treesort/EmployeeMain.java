package com.user.treesort;

import java.util.Iterator;
import java.util.TreeSet;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee(111,"Kiran",7400f);
		Employee e2=new Employee(101,"Ram",1298f);
		Employee e3=new Employee(121,"Savi",1993f);
		Employee e4=new Employee(151,"Kavita",8114f);
		
		
		TreeSet<Employee> tst=new TreeSet<Employee>(new EmployeeIDSort());
		tst.add(e1);
		tst.add(e2);
		tst.add(e3);
		tst.add(e4);
		System.out.println("Sorting based on ID");
		Iterator<Employee> itemp=tst.iterator();
		while(itemp.hasNext()) {
			Employee e=itemp.next();
			System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
		}
		

		TreeSet<Employee> tst1=new TreeSet<Employee>(new EmployeeNameSort());
		tst1.add(e1);
		tst1.add(e2);
		tst1.add(e3);
		tst1.add(e4);
		System.out.println("Sorting based on Name");
		Iterator<Employee> itemp1=tst1.iterator();
		while(itemp1.hasNext()){
			Employee ep=itemp1.next();
			System.out.println(ep.eid+"\t"+ep.ename+"\t"+ep.esalary);
		}
		
		TreeSet<Employee> tst2=new TreeSet<Employee>(new EmployeeSalarySort());
		tst2.add(e1);
		tst2.add(e2);
		tst2.add(e3);
		tst2.add(e4);
		System.out.println("Sorting based on Salary in descending order");
		Iterator<Employee> itemp2=tst2.descendingIterator();
		while(itemp2.hasNext()){
			Employee emp=itemp2.next();
			System.out.println(emp.eid+"\t"+emp.ename+"\t"+emp.esalary);
		}
	}

}
