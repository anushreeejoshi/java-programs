package com.user.hashset;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee(132, "Shree", 21333f);
		Employee e2=new Employee(100, "Vani", 6233f);
		Employee e3=new Employee(112, "Ram", 3233f);
		Employee e4=new Employee(182, "Anaya", 21779f);
		
		
		HashSet<Employee> hsh1=new HashSet<Employee>();
		hsh1.add(e1);
		hsh1.add(e2);
		hsh1.add(e3);
		hsh1.add(e4);
		
		SortIDEmployee sie=new SortIDEmployee();
//		Collections.sort(hsh1,sie); only work with list
		Iterator<Employee> it1=hsh1.iterator();
		while(it1.hasNext()) {
			Employee e=it1.next();
			System.out.println(e.eid+"\t"+e.ename+"\t"+e.esalary);
		}
	}

}
