package com.javaedu;

public class AreaTriRecSqu {

	public static void main(String args[]) {
		
		int length=12;
		int bredth=13;
		int AreaRec=length*bredth;
		System.out.println("Area of Rectengle="+AreaRec);
		
		int side1=10;
		int side2=15;
		int AreaofSqua=side1*side2;
		System.out.println("Area of Square="+AreaofSqua);
		
		double base=18;
		double height=20;
		double AreaofTri=(base*height)/2;
		System.out.println("Area of Tringle="+AreaofTri);
		
		double pi=3.14159;
	    double radius=24.3;
	    double AreaofCir=pi*radius*radius;
	    System.out.println("Area of Circle="+AreaofCir);
		
	}
}
