package com.javaedu;

public class DataTypes {
public static void main(String args[]) {
int num=10;
float fval=34.44f;
double dval=23.44;
char ch='A';
String name="Anushree";

System.out.println("int num="+num);
System.out.println("float fval="+fval);
System.out.println("double dval="+dval);
System.out.println("char ch="+ch);
System.out.println("String name="+name);


}
}
