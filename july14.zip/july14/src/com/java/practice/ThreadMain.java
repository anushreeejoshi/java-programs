package com.java.practice;
class FirstClass extends Thread{
	@Override
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println(Thread.currentThread());
		}
	}
}
class FirstClass1 implements Runnable{ //one way of creating a thread by implementing runnable
	@Override
	public void run() {
		for(int i=0;i<=5;i++) {
			System.out.println(Thread.currentThread());
		}
	}
}
public class ThreadMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Thread.currentThread());
		FirstClass ob=new FirstClass();
		FirstClass ob1=new FirstClass();
		ob.setName("First Thread"); //change name of the thread
		ob.start();
		ob1.setName("Second Thread");
		ob1.start();
		//implements runnable 
		FirstClass1 obj=new FirstClass1();
		FirstClass1 obj1=new FirstClass1();
		Thread tob=new Thread(obj);
		Thread tob1=new Thread(obj1);
		tob.setName("firstthread_Run");//change the name of thread
		tob1.setName("secondthread_Run");
		tob.start();
		tob1.start();
	}

}
