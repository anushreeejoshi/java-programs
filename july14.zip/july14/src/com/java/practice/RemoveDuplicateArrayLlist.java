package com.java.practice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeSet;

public class RemoveDuplicateArrayLlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> lst=new ArrayList<String>();
		lst.add("Anu");
		lst.add("Shivi");
		lst.add("Jack");
		lst.add("Aman");
		lst.add("Aman");
		
		
		Iterator<String> it=lst.iterator();
		TreeSet<String> ts=new TreeSet<String>();
		
		while(it.hasNext()) {
			
			ts.add(it.next());
		
		}
		System.out.println(ts);
	}

}
