package com.javastring;

import java.util.Scanner;

public class CountChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any string value");
		String s=sc.nextLine();
		int len=s.length();
		int count=0;
		
		
			for(int i=0;i<len;i++) {
				char ch=s.charAt(i);
				if(len>count && ch!=' ') {
				count++;
			}
			
		}
			System.out.println("No. of chars in "+s+" is: "+count);
	}

}
