//string pool  and heap memory
package com.javastring;

public class StringObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Hello";
		String s1="Hello";
		
		String s2=new String("Hello");
		String s3=new String("Hello");
		
		if(s==s1) { //compare address
			System.out.println("s and s1 has same address");
		}else {
			System.out.println("s and s1 has different address");
		}
		if(s1.equals(s3)) {
			System.out.println("s1 and s3 has same info");
		}else {
			System.out.println("s1 and s3 has different info");
		}
		if(s1==s3) {
			System.out.println("s1 and s3 has same address");
		}else {
			System.out.println("s1 and s3 has different address");
		}
		
		if(s2.equals(s3)) { //compare content
			System.out.println("s2 and s3 has same info");
		}else {
			System.out.println("s2 and s3 has different info");
		}
		}
	}


