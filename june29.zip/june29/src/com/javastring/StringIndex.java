package com.javastring;

public class StringIndex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="hello";
		System.out.println("index of l:"+s.indexOf('l')); //left to right 2
		System.out.println("index of l:"+s.lastIndexOf('l')); //right to left 3
	}

}
