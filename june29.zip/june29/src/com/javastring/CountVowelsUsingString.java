package com.javastring;

public class CountVowelsUsingString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="Hello World";
		int vc=0;
		int l=s.length();
		System.out.println("No. of chars="+l);
		for(int i=0;i<l;i++) {
			char ch=s.charAt(i);
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U'||ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				vc++;
			}
		}
		System.out.println("No. of vowels="+vc);
	}

}
