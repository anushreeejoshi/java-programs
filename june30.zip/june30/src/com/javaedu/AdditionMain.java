//constructors overloading same name(constructor) but different arguments
package com.javaedu;

 class Addition_One{
	int a,b,s;
	
	Addition_One(){ //constructor with no arguments
		a=10;
		b=56;
		System.out.println("Constructor is called");
		System.out.println("Constructor is used to initialize the memeber dta of the class");
	}
	void add() {
		s=a+b;
		System.out.println("sum is:"+s);
	}
	
	
	Addition_One(int i,int j){ //constructor with two arguments
		System.out.println("Contructor is called");
		a=i;
		b=j;
	}
}
public class AdditionMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		Addition_One add=new Addition_One();//constructor called
		add.add();
		Addition_One add2=new Addition_One(3,4);
		add2.add();
		Addition_One add3=new Addition_One(12,32);
		add3.add();
	}

}
