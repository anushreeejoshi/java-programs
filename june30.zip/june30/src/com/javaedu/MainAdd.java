package com.javaedu;

class AddOverload{
	
	void add(int i,int j) {
		System.out.println("sum is:"+(i+j));
	}
	void add(float i,float j) {
		System.out.println("sum is:"+(i+j));
	}
	void add(double i,int j,double k) {
		System.out.println("sum is:"+(i+j+k));
	}
	void add(short i, short j) {
		System.out.println("sum is:"+(i+j));
	}
	void add(byte i, byte j) {
		System.out.println("sum is:"+(i+j));
	}
}
public class MainAdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AddOverload addobj=new AddOverload();
		addobj.add(12, 13);
		addobj.add(12.3f, 13.f);
		addobj.add(12.34, 14, 13.45);
		addobj.add((short)1,(short) 2); //explicitly casting short
		addobj.add((byte)2, (byte)4);   //explicitly casting byte
	}

}
