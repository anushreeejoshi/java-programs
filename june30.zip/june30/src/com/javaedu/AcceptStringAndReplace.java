package com.javaedu;

import java.util.Scanner;

public class AcceptStringAndReplace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any string: ");
		String s=sc.nextLine().toUpperCase();
		int len=s.length();
		String str=" ";
		for(int i=0;i<len;i++) {
			char ch=s.charAt(i);
			if(ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
				str=str+"*";
			}else {
				str=str+ch;
			}
			
		}
		System.out.print(str);
		
	}

}
