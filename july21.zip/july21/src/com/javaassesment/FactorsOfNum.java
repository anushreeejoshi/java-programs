package com.javaassesment;

import java.util.Scanner;

class Factors{
	
	void factor(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any no");
		int num=sc.nextInt();
		System.out.println("Factors of "+num );
		for(int i=1;i<=num;i++) {
			if(num%i==0) {
				
				System.out.println(i);
			}
		}
	}
}
public class FactorsOfNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Factors ob=new Factors();
    ob.factor();
		
	}

}
