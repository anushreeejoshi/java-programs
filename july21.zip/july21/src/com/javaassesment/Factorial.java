package com.javaassesment;

import java.util.Scanner;
class FactorialFind{
	double fact=1;
	
	void factorial() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any number:");
		int num=sc.nextInt();
		System.out.println("fatctorial of "+num);
		for(int i=1;i<=num;i++) {
			fact=fact*i;
			System.out.println(fact);
		}
		
	}
}
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		FactorialFind ob=new FactorialFind();
		ob.factorial();
		
	}

}
