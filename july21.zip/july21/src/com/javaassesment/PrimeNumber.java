package com.javaassesment;

class Prime{
	int c=0;
	void generatePrime() {
		System.out.println("Generating Prime No. Series");
		for(int i=1;i<=100;i=i+2) {
			c=0;
			for(int j=1;j<=i;j++) {
				if(i%j==0) {
					c++;
				}
			}
			if(c==2) {
				System.out.println(i+" ");
			}
			
	}
}
}
public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Prime pob=new Prime();
		pob.generatePrime();
		
		
	    

}
}
