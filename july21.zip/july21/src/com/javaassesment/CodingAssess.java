package com.javaassesment;

import java.util.Scanner;

class LargestOfTwo{
	int a,b;
	
	public void inputData() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Two Number:");
		a=sc.nextInt();
		b=sc.nextInt();
		
	}
	public void largest() {
//		if(a>b) {
//			System.out.println(a+" Is greater");
//		}
//		else {
//			System.out.println(b+" Is greater");
//		}
		int c=(a>b)?a:b;
		System.out.println(c);
	}
}
public class CodingAssess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LargestOfTwo ob=new LargestOfTwo();
		ob.inputData();
		ob.largest();
	}

}
