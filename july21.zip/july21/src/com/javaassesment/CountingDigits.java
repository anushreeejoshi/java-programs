package com.javaassesment;

import java.util.Scanner;

class CountNum{
	int no,count;
	int rev;
	public CountNum(int a) {
		// TODO Auto-generated constructor stub
		no=a;
	}
	void count() {
		int temp=no;
		while(temp!=0) {
			int digit=temp%10;
		    rev=rev*10+digit;
			temp=temp/10;
			//count++;
			
		}
		System.out.println(rev);
	}
	void palindrome() {
		
//		System.out.println(temp+"and"+no);
		if(no==rev) {
			System.out.println("Number is palindrome");
		}
		else {
			System.out.println("Number is not palindrome");
		}
	}
}
public class CountingDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number:");
		int no=sc.nextInt();
		CountNum ob=new CountNum(no);
		
		ob.count();
		ob.palindrome();
	}

}
