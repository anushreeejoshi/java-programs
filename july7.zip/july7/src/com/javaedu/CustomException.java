package com.javaedu;

class AgeCheckException extends Exception{
	public AgeCheckException(String s) {
		super(s);
	}
}
class VoteAge{
	public void checkAgeVote(int age) {
		if(age<18) {
			try {
//				throw new AgeCheckException("not eligible for voting");
			
			AgeCheckException erob=new AgeCheckException("not eligible for voting");
			throw erob;
			
		}catch(AgeCheckException e) {
			e.printStackTrace();
		}
	}else {
		System.out.println("Eligible for voting");
	}
}
}
public class CustomException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		VoteAge vob=new VoteAge();
		vob.checkAgeVote(2);
	}

}
