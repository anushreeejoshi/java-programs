package com.javaedu;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BufferesReader {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		int age;
		String name;
		float fees;
		
		InputStreamReader in=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(in);
		System.out.println("Enter name:");
		name=br.readLine();
		System.out.println("Enter age:");
		age=Integer.parseInt(br.readLine());
		System.out.println("Enter fees:");
		fees=Float.parseFloat(br.readLine());
		
		System.out.println("Name="+name);
		System.out.println("Age="+age);
		System.out.println("Fees="+fees);
	}

}
