package com.user.thread;
class MyThread extends Thread{
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread()+"i"+i);
			//pause currently executing thread
			
		}
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class ThreadMainApp {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		MyThread tob=new MyThread();
		MyThread tob1=new MyThread();
		tob.setName("first");
		tob1.setName("second");
		System.out.println(tob+"is alive "+tob.isAlive()); //to check alive or not
		tob.start();//runnable state
		            //whenever JVM starts execution of the objects
		            //from runnable state it goes to run state
		System.out.println(tob+"is alive "+tob.isAlive());
		System.out.println(tob1+"is alive "+tob1.isAlive());
		tob.join();//Waits for first thread  thread to die. 
		System.out.println(tob+"is alive "+tob.isAlive());//
		tob1.start();//Causes this thread to begin execution; 
		            //the Java Virtual Machine calls the run method of this thread. 		
		System.out.println(tob1+"is alive "+tob1.isAlive());
	}

}
