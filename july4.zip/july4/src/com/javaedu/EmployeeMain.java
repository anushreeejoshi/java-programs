package com.javaedu;

import java.util.Scanner;

class Employee{
	int eid;
	String ename;
	float esalary;
	public Employee(int eid,String ename,float esalary) {
		this.eid=eid;
		this.ename=ename;
		this.esalary=esalary;
	}
	public Employee(){
		
	}
	void display() {
		System.out.println("Your id="+eid);
		
		System.out.println("Your name="+ename);
		
		System.out.println("Your salary="+esalary);
		
	}
	public void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		ename=sc.nextLine();
		
		System.out.println("Enter id:");
		eid=sc.nextInt();
		
		System.out.println("Enter salary:");
		esalary=sc.nextFloat();
	}
	 
	 public int getEid() {
			// TODO Auto-generated method stub
			return eid;
		}
	 public void setEid(int i) {
			// TODO Auto-generated method stub
			this.eid=eid;
		}
	 public String getEname() {
			// TODO Auto-generated method stub
			return ename;
		}
	 public void setEname(String string) {
			// TODO Auto-generated method stub
			
		}
	 public float getSalary() {
			// TODO Auto-generated method stub
			return esalary ;
		}
	 public void setSalary(float f) {
			// TODO Auto-generated method stub
			
		}
	
	
	
	
	
	
}
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee(10, "Anu", 2352.2f);
		Employee e2=new Employee(12,"sakshi",6234.1f);
		Employee e3=new Employee(13, "akshi", 2631.2f);
		e1.display();
		e2.display();
		e3.display();
		
//		constructor
		Employee ob=new Employee();
		ob.input();
		ob.display();
		
		
		
//		getter setter
		Employee eobj=new Employee();
		eobj.setEid(76);
		eobj.setEname("Ravi");
		eobj.setSalary(6352.4f);
		
		System.out.println(eobj.getEid());
		System.out.println(eobj.getEname());
		System.out.println(eobj.getSalary());
	}

}
