package com.javaedu;

class A{
	A(){
		System.out.println("Class A const");
	}
	
}
class B extends A{
	B(){
		System.out.println("Class B Const");
	}
}
class C extends B{
	public C() {
		System.out.println("C Class Const");
	}
}
public class ConstructorMainInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		C ob=new C();
	}

}
