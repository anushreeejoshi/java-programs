package com.javaedu;



class Employee1{ //if the class is final you cannot have child class
//	final int i=10; cannot change the value final is like constant
	
//	final void inputData() { //if the method is final you cannot override in the subclass
//		int i=20;
//		System.out.println(i);
//	}
	String name;
	static String companyname;
	static { //used for static data initialization
		companyname="Edubridge";
		System.out.println("static1");
		
	}
	static {
		System.out.println("static2");
	}
	public static void staticMethod() { //static method override
		
		System.out.println("Static method employee"+companyname);
	}
	public void nonstaticmethod() {
		System.out.println("name="+name);
		System.out.println("static= "+companyname);
	}
}
	class Accountant extends Employee1{
		
		public static void staticMethod() {
			//super.staticMethod(); //inside static method cannot be used static method cannot be overridden
			System.out.println("Static method Accountant");
			
		}
	}

public class FinalStaticMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Accountant aob=new Accountant();
//		aob.inputData();
		aob.staticMethod();
		Employee1.staticMethod();//static method can be called with ref to classname or object
		
	}

}
