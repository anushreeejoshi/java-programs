package com.javaedu;

import java.util.Scanner;

class Student{
	int sid;
	String sname;
	float sfees;
	public Student() {
		
	}
	public void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name: ");
		sname=sc.nextLine();
		System.out.println("Enter fees: ");
		sfees=sc.nextFloat();
		System.out.println("enter id: ");
		sid=sc.nextInt();
	}
	public void display() {
		System.out.println("ID="+sid);
		System.out.println("Name="+sname);
		System.out.println("Fees="+sfees);
	}
}
public class ArrayOfObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Student sob[]=new Student[5];
	for(int i=0;i<sob.length;i++) {
		sob[i]=new Student();
		
	}
	for(int i=0;i<sob.length;i++) {
		sob[i].input();
	}
	System.out.println("All student records");
	for(int i=0;i<sob.length;i++) {
		sob[i].display();
	}
	}

}
