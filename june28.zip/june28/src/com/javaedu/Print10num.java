package com.javaedu;

public class Print10num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Print 1 to 10 Numbers:");
		for(int i=1;i<=10;i++) {
			System.out.println(i);
		}
	}

}
