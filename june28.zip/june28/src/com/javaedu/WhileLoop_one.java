package com.javaedu;

public class WhileLoop_one {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Print 1 to 5 using while loop:");
		int i=1;
		while(i<=5){
			
			System.out.println(i);
			i++;
		}
	}

}
