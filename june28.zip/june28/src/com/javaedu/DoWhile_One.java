package com.javaedu;

public class DoWhile_One {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=10;
		
		do {
			System.out.println("Value of i is: "+i);
			i++;
		}while(i<=20);
	}

}
